﻿using System;

namespace SnkrBot.Models
{
    public class FilterDetails
    {
        public string Filter { get; set; }
        public string Brand { get; set; }
        public double? MaxPrice { get; set; }
    }
}